# midog25

Drive: https://drive.google.com/drive/folders/1QcI1VtQm1Ajlw81RNKXsxQFyX07RlW6u?usp=drive_link \
Notes: https://docs.google.com/document/d/1pXl-Ag_ovNSsyRtFmyi7YP4LNCU6FOWWO3873KLEwxc/edit?usp=sharing \
Experiments: https://docs.google.com/spreadsheets/d/14RVgut0LnhMmQvQtLns5e52y90zqoFTlmiAs9jTiqf4/edit?usp=sharing
